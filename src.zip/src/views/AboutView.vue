<script setup>

import Volver from '@/components/Volver.vue';









</script>




<template>
  <div class="about">
    <h1>Examen Vue</h1>
    <h2>Carro compra </h2>
    <h3>Components + Vue Router + Composables + Pinia
    </h3>
    <h3>Iker Redondo Serra
    </h3>
    <Volver />
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    margin-top: 350px;
    align-items: center;
  }
}
</style>
