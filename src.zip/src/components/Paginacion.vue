<script setup>
//importamos ref de vue y definimos los emits y los props
//emits llamada a los metodos getDataPrev y getDataNext
//props el id del articulo
import { ref } from "vue";
const emit = defineEmits(['getDataPrev', 'getDataNext']);
const recive = defineProps(['id']);
console.log(recive);

/*

function ocultarBotonPrev(id) {

    console.log(id.value);


    if (idu.value == 1) {

        return true;

    } else {

        return false;
    }
}

function ocultarBotonNext(id) {


    if (id.value == 20) {

        return true;

    } else {

        return false;
    }
}




:disabled="ocultarBotonNext(id)"
:disabled="ocultarBotonPrev(id)"
*/


</script>
<template>
    <button @click="emit('getDataPrev', id)" type="button" id="prev">Prev</button>
    <button @click="emit('getDataNext', id)" type="button" id="next">Next</button>
</template>