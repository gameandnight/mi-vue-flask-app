<script setup>
//imports de RouterLink y el composable useGetData
import { RouterLink } from "vue-router";
import { useGetData } from '@/composables/useGetData'

//llamada al composable con el metodo y variables que devolvera
const { getData, datos, error , cargando} = useGetData(); //Datos dev por el composable
//obtenemos los datos llamando con el metodo getData pasandole la url
getData('https://fakestoreapi.com/products/');


</script>

<template>
  <h1 v-if="cargando">cargando</h1>
  <h1 v-else-if="error">Error de Conexion</h1>
  <div v-else-if="datos">

    <ul>
      <li v-for="art in datos"> <!-- los datos nos los pasa  el composable-->
        Articulo {{ art.id }}
        <router-link :to="`/${art.id}`">
          <img :src="art.image" /><br>
        </router-link>
      </li>
    </ul>
  </div>
<!-- <Paginacion :datos="datos" @getDataPrev="getDataPrev" @getDataNext="getDataNext" />--></template>


<style>
img {
  width: 200px;
  height: 200px;
}
</style>
