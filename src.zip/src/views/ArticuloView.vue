<script setup>

//importamos axios, ref de vue,  useRoute, useRouter, useGetData, el componente Volver y Paginacion
import axios from 'axios';
import { ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useGetData } from '@/composables/useGetData'
import Volver from '@/components/Volver.vue';
import Paginacion from '@/components/Paginacion.vue';

//variable que recoge la id del producto
var id = ref();
//adjudicamos tanto al useRoute y el useRouter a sus constantes
const router = useRouter();
const route = useRoute();




//llamada al composable con el metodo y variables que devolvera
const { getData, datos, error, cargando } = useGetData(); //Datos dev por el composable
getData(`https://fakestoreapi.com/products/${route.params.articulo}`);


//funcion para acceder al proximo articulo, recibe el id del articulo actual
function getDataNext(id) {

  //se aumenta su valor
  id.value = id.value + 1;
  //se accede al proximo producto
  getData(`https://fakestoreapi.com/products/` + id.value);
}

//el mismo proceso que el metodo anterior pero accede al elemento anterior
function getDataPrev(id) {
  id.value = id.value - 1;
  getData(`https://fakestoreapi.com/products/` + id.value);
}
//se le asigna a id el valor del id del articulo actual
id.value = route.params.articulo;
console.log(id.value);









</script>
<template>
  <h1 v-if="cargando">cargando</h1>
  <h1 v-else-if="error">Error de Conexion</h1>
  <div v-else-if="datos">
    <h2>Articulo: {{ datos.title }}</h2>
    <p>{{ datos.description }}</p>
    <p>Precio. {{ datos.price }}</p>
    <img :src="datos.image" /><br>
    <Volver />
    <Paginacion :id="id" @getDataPrev="getDataPrev" @getDataNext="getDataNext" />
    <!--<button @click="anyadir(datos)">Comprar</button>-->

  </div>
</template>

<style>
img {
  width: 250px;
  height: 250px;
}
</style>
