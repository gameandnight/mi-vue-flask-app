<script setup>
//importamos axios, ref de vue , el  useRoute , useRouter y el composable useGetData

import axios from 'axios';
import { ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useGetData } from '@/composables/useGetData'

//adjudicamos tanto al useRoute y el useRouter a sus constantes
const router = useRouter();
const route = useRoute();


//metodo volver para volver a Home
const volver = () => {
    router.push("/"); //Indicamos la ruta
};


</script>
<template>
    <button @click="volver">Volver</button>
</template>