import axios from 'axios'
import { ref } from 'vue'
//exportamos el composable para poder usarlo en otros sitios
export const useGetData = () => {
    const datos = ref(null); //asignamos null a la variable datos 
    const error = ref(false);//asignamos false a la variable error
    var cargando = ref(true);//asiganamos false a la variable cargando

    //funcion asincrona para obttener los datos
    const getData = async (url) => {
        try { //esperamos a obtener los resultados del API en la variable resultado
            const resultado = await axios.get(url);
            datos.value = resultado.data; //guardamos el resultado en la variable datos

        }
        catch (e) { //si hay algun error lo muestro por consola y le doy el valor de true a la variable error
            console.log(e);
            error.value = true;
        } finally {
            cargando.value = false;
        }
    };
    return {
        getData, //Retornamos nuestra funcion
        datos, //Retornamos el resultado obtenido
        error,//retornamos el error
        cargando
    }
}; 
